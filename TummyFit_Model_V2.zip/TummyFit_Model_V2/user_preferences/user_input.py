from user_preferences.preferences import meal_preferences

# Input dari user
halal_preference = input("Do you prefer halal meals? (yes/no): ")
vegetarian_preference = input("Do you prefer vegetarian meals? (yes/no): ")
vegan_preference = input("Do you prefer vegan meals? (yes/no): ")
gluten_free_preference = input("Do you prefer gluten-free meals? (yes/no): ")
dairy_free_preference = input("Do you prefer dairy-free meals? (yes/no): ")

# Memanggil fungsi dan menyimpan hasilnya dalam sebuah variabel
meal_preferences = meal_preferences(halal_preference, vegetarian_preference, vegan_preference, gluten_free_preference, dairy_free_preference)

# Menampilkan hasil meal preferences
print(f"Your meal preferences are: {meal_preferences}")