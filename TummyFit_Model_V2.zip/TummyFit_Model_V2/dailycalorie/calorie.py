def calculate_daily_calorie_requirement(weight, height, sex, age, daily_activity, goal):
    # Menghitung BMR (Basal Metabolic Rate)
    if sex == "male":
        bmr = 66 + (13.75 * weight) + (5 * height) - (6.75 * age)
    elif sex == "female":
        bmr = 655 + (9.56 * weight) + (1.85 * height) - (4.68 * age)
    else:
        raise ValueError("Invalid sex. Please enter 'male' or 'female'.")

    # Menyesuaikan kebutuhan kalori berdasarkan aktivitas harian
    activity_factors = {
        "sedentary": 1.2,
        "lightly active": 1.375,
        "moderately active": 1.55,
        "very active": 1.725,
        "extra active": 1.9
    }
    if daily_activity not in activity_factors:
        raise ValueError("Invalid daily activity. Please choose from: 'sedentary', 'lightly active', 'moderately active', 'very active', 'extra active'.")
    
    daily_calorie_requirement = bmr * activity_factors[daily_activity]

    # Menyesuaikan kebutuhan kalori berdasarkan tujuan
    if goal == "Maintain weight":
        return daily_calorie_requirement
    elif goal == "Weight loss":
        # Mengurangi 500 kalori per hari untuk tujuan penurunan berat badan
        calorie_deficit = 500
        return daily_calorie_requirement - calorie_deficit
    else:
        raise ValueError("Invalid goal. Please choose from: 'Maintain weight' or 'Weight loss'.")