import tensorflow as tf
import numpy as np
import pandas as pd
from dailycalorie.calculate_calorie import calorie_requirement as cc_calorie_requirement
from user_preferences.user_input import *

def generate_weekly_meal_plan(calorie_requirement):
    # Load the encoded data
    data_encoded = pd.read_csv('data/data_encoded.csv')

    # Load the saved model
    model = tf.keras.models.load_model('model/calorie_model.h5')

    # Generate the weekly meal plan
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    meal_categories = ['Breakfast', 'Lunch', 'Dinner', 'Snack 1', 'Snack 2']
    meal_plan = {}

    for day in days:
        daily_plan = {}
        remaining_calories = calorie_requirement
        for category in meal_categories:
            valid_recipes = data_encoded[data_encoded[category] == 1]
            # Include user preferences in the selection of valid recipes
            if halal_preference.lower() == 'yes':
                valid_recipes = valid_recipes[valid_recipes['Halal'] == 1]
            if vegetarian_preference.lower() == 'yes':
                valid_recipes = valid_recipes[valid_recipes['Vegetarian'] == 1]
            if vegan_preference.lower() == 'yes':
                valid_recipes = valid_recipes[valid_recipes['Vegan'] == 1]
            if gluten_free_preference.lower() == 'yes':
                valid_recipes = valid_recipes[valid_recipes['Gluten Free'] == 1]
            if dairy_free_preference.lower() == 'yes':
                valid_recipes = valid_recipes[valid_recipes['Dairy Free'] == 1]
                
            valid_recipes = data_encoded[data_encoded[category] == 1]
            valid_recipes = valid_recipes[~valid_recipes['Recipe Title'].isin(list(daily_plan.values()))]
            valid_recipes = valid_recipes[valid_recipes['Calories'] <= remaining_calories]
            if len(valid_recipes) > 0:
                predicted_calories = model.predict(valid_recipes[['Calories', 'Breakfast', 'Lunch', 'Dinner', 'Snack 1', 'Snack 2', 'Halal', 'Vegan', 'Vegetarian', 'Gluten Free', 'Dairy Free']])
                valid_recipes['Predicted Calories'] = predicted_calories.flatten()
                valid_recipes = valid_recipes[(valid_recipes['Predicted Calories'] <= remaining_calories) | (valid_recipes[category] == 1)]
                if len(valid_recipes) > 0:
                    random_index = np.random.randint(len(valid_recipes))
                    recipe = valid_recipes.iloc[random_index]['Recipe Title Original']
                    calories = valid_recipes.iloc[random_index]['Calories']
                    ingredients = valid_recipes.iloc[random_index]['Ingredients']
                    instructions = valid_recipes.iloc[random_index]['Instructions']
                    daily_plan[category] = (recipe, calories, ingredients, instructions)
                    remaining_calories -= calories
        meal_plan[day] = daily_plan

    return meal_plan, meal_categories

def print_weekly_meal_plan(meal_plan, meal_categories, calorie_requirement):
    for day, daily_plan in meal_plan.items():
        print(day)
        print(f"Your daily calorie requirement = {calorie_requirement} calories")
        print("-----------------------------")
        for category in meal_categories:
            if category in daily_plan:
                recipe, calories, ingredients, instructions = daily_plan[category]
                print(f'{category}:')
                print(f'Recipe: {recipe}')
                print(f'Calories: {calories}')
                print(f'Ingredients: {ingredients}')
                print(f'Instructions: {instructions}')
                print("-----------------------------")
        total_calories = sum([plan[1] for plan in daily_plan.values()])
        print(f'Total calories for {day}: {total_calories} calories')
        print("=============================\n")

if __name__ == '__main__':
    calorie_requirement = cc_calorie_requirement
    data_encoded = pd.read_csv('data/data_encoded.csv')
    meal_plan, meal_categories = generate_weekly_meal_plan(calorie_requirement)
    print_weekly_meal_plan(meal_plan, meal_categories, calorie_requirement)
