def meal_preferences(halal_preference, vegetarian_preference, vegan_preference, gluten_free_preference, dairy_free_preference):
    preferences = []
    if halal_preference.lower() == 'yes':
        preferences.append('Halal')
    if vegetarian_preference.lower() == 'yes':
        preferences.append('Vegetarian')
    if vegan_preference.lower() == 'yes':
        preferences.append('Vegan')
    if gluten_free_preference.lower() == 'yes':
        preferences.append('Gluten Free')
    if dairy_free_preference.lower() == 'yes':
        preferences.append('Dairy Free')

    if preferences:
        preferences_str = ', '.join(preferences)
        return preferences_str
    else:
        return "You have no specific meal preferences."
