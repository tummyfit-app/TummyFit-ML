from .calorie import calculate_daily_calorie_requirement

# Input dari pengguna
weight = float(input("Masukkan berat badan Anda (dalam kilogram): "))
height = float(input("Masukkan tinggi badan Anda (dalam sentimeter): "))
sex = input("Masukkan jenis kelamin Anda ('male' atau 'female'): ")
age = int(input("Masukkan usia Anda (dalam tahun): "))
daily_activity = input("Masukkan tingkat aktivitas harian Anda ('sedentary', 'lightly active', 'moderately active', 'very active', 'extra active'): ")
goal = input("Masukkan tujuan Anda ('Maintain weight' atau 'Weight loss'): ")

calorie_requirement = calculate_daily_calorie_requirement(weight, height, sex, age, daily_activity, goal)
print(f"Kebutuhan kalori per hari: {calorie_requirement} kalori")